﻿namespace Aknakereso
{
    partial class JatekAblak
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mezoPanel = new System.Windows.Forms.Panel();
            this.kilepesB = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pontszam1L = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pontszam2L = new System.Windows.Forms.Label();
            this.AknaszamL = new System.Windows.Forms.Label();
            this.kilepesMenu = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // mezoPanel
            // 
            this.mezoPanel.BackColor = System.Drawing.Color.Transparent;
            this.mezoPanel.Location = new System.Drawing.Point(12, 12);
            this.mezoPanel.Name = "mezoPanel";
            this.mezoPanel.Size = new System.Drawing.Size(250, 250);
            this.mezoPanel.TabIndex = 2;
            // 
            // kilepesB
            // 
            this.kilepesB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.kilepesB.BackColor = System.Drawing.Color.OliveDrab;
            this.kilepesB.Location = new System.Drawing.Point(620, 397);
            this.kilepesB.Name = "kilepesB";
            this.kilepesB.Size = new System.Drawing.Size(105, 30);
            this.kilepesB.TabIndex = 3;
            this.kilepesB.Text = "Kilépés a játékból";
            this.kilepesB.UseVisualStyleBackColor = false;
            this.kilepesB.Click += new System.EventHandler(this.kilepesB_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(616, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 40);
            this.label1.TabIndex = 4;
            this.label1.Text = "Játékos\r\npontszáma:";
            // 
            // pontszam1L
            // 
            this.pontszam1L.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pontszam1L.AutoSize = true;
            this.pontszam1L.BackColor = System.Drawing.Color.Transparent;
            this.pontszam1L.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.pontszam1L.Location = new System.Drawing.Point(714, 32);
            this.pontszam1L.Name = "pontszam1L";
            this.pontszam1L.Size = new System.Drawing.Size(31, 20);
            this.pontszam1L.TabIndex = 5;
            this.pontszam1L.Text = "0 p";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(616, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 40);
            this.label2.TabIndex = 6;
            this.label2.Text = "Ellenfél\r\npontszáma:";
            // 
            // pontszam2L
            // 
            this.pontszam2L.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pontszam2L.AutoSize = true;
            this.pontszam2L.BackColor = System.Drawing.Color.Transparent;
            this.pontszam2L.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.pontszam2L.ForeColor = System.Drawing.Color.Black;
            this.pontszam2L.Location = new System.Drawing.Point(714, 97);
            this.pontszam2L.Name = "pontszam2L";
            this.pontszam2L.Size = new System.Drawing.Size(31, 20);
            this.pontszam2L.TabIndex = 7;
            this.pontszam2L.Text = "0 p";
            // 
            // AknaszamL
            // 
            this.AknaszamL.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AknaszamL.AutoSize = true;
            this.AknaszamL.BackColor = System.Drawing.Color.Transparent;
            this.AknaszamL.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.AknaszamL.ForeColor = System.Drawing.Color.Black;
            this.AknaszamL.Location = new System.Drawing.Point(616, 140);
            this.AknaszamL.Name = "AknaszamL";
            this.AknaszamL.Size = new System.Drawing.Size(88, 20);
            this.AknaszamL.TabIndex = 8;
            this.AknaszamL.Text = "Aknaszám:";
            // 
            // kilepesMenu
            // 
            this.kilepesMenu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.kilepesMenu.BackColor = System.Drawing.Color.OliveDrab;
            this.kilepesMenu.Location = new System.Drawing.Point(12, 397);
            this.kilepesMenu.Name = "kilepesMenu";
            this.kilepesMenu.Size = new System.Drawing.Size(105, 30);
            this.kilepesMenu.TabIndex = 10;
            this.kilepesMenu.Text = "Kilépés a menübe";
            this.kilepesMenu.UseVisualStyleBackColor = false;
            this.kilepesMenu.Click += new System.EventHandler(this.KilepesMenu_Click);
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Yellow;
            this.label3.Location = new System.Drawing.Point(323, 359);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(99, 20);
            this.label3.TabIndex = 11;
            this.label3.Text = "Segítségek";
            // 
            // radioButton1
            // 
            this.radioButton1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.radioButton1.AutoSize = true;
            this.radioButton1.BackColor = System.Drawing.Color.OliveDrab;
            this.radioButton1.ForeColor = System.Drawing.Color.Black;
            this.radioButton1.Location = new System.Drawing.Point(177, 404);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(80, 17);
            this.radioButton1.TabIndex = 12;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Függőleges";
            this.radioButton1.UseVisualStyleBackColor = false;
            // 
            // radioButton2
            // 
            this.radioButton2.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.radioButton2.AutoSize = true;
            this.radioButton2.BackColor = System.Drawing.Color.OliveDrab;
            this.radioButton2.ForeColor = System.Drawing.Color.Black;
            this.radioButton2.Location = new System.Drawing.Point(342, 404);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(64, 17);
            this.radioButton2.TabIndex = 13;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Négyzet";
            this.radioButton2.UseVisualStyleBackColor = false;
            // 
            // radioButton3
            // 
            this.radioButton3.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.radioButton3.AutoSize = true;
            this.radioButton3.BackColor = System.Drawing.Color.OliveDrab;
            this.radioButton3.ForeColor = System.Drawing.Color.Black;
            this.radioButton3.Location = new System.Drawing.Point(486, 404);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(73, 17);
            this.radioButton3.TabIndex = 14;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Vízszintes";
            this.radioButton3.UseVisualStyleBackColor = false;
            // 
            // JatekAblak
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackgroundImage = global::Aknakereso.Properties.Resources.Aknamezo;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(754, 437);
            this.Controls.Add(this.radioButton3);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.kilepesMenu);
            this.Controls.Add(this.AknaszamL);
            this.Controls.Add(this.pontszam2L);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pontszam1L);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.kilepesB);
            this.Controls.Add(this.mezoPanel);
            this.MaximizeBox = false;
            this.Name = "JatekAblak";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Aknakereső";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.JatekAblak_FormClosing);
            this.Load += new System.EventHandler(this.JatekAblak_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel mezoPanel;
        private System.Windows.Forms.Button kilepesB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label pontszam1L;
        public System.Windows.Forms.Label pontszam2L;
        private System.Windows.Forms.Label AknaszamL;
        private System.Windows.Forms.Button kilepesMenu;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;


    }
}

