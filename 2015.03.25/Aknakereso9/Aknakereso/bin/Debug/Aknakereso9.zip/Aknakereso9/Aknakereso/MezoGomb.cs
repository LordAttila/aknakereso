﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Aknakereso
{
    class MezoGomb : FedoGomb
    {
        private int ertek;

        public MezoGomb(int pozicioX, int pozicioY) : base(pozicioX, pozicioY, 0, 0){
        }
    }
}
