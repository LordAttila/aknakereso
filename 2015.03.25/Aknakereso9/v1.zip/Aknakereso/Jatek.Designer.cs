﻿namespace Aknakereso
{
    partial class JatekAblak
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.kilepesB = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pontszam1L = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pontszam2L = new System.Windows.Forms.Label();
            this.AknaszamL = new System.Windows.Forms.Label();
            this.KilepesMenu = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(250, 250);
            this.panel1.TabIndex = 2;
            // 
            // kilepesB
            // 
            this.kilepesB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.kilepesB.BackColor = System.Drawing.Color.OliveDrab;
            this.kilepesB.Location = new System.Drawing.Point(308, 235);
            this.kilepesB.Name = "kilepesB";
            this.kilepesB.Size = new System.Drawing.Size(105, 30);
            this.kilepesB.TabIndex = 3;
            this.kilepesB.Text = "Kilépés a játékból";
            this.kilepesB.UseVisualStyleBackColor = false;
            this.kilepesB.Click += new System.EventHandler(this.kilepesB_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(304, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 40);
            this.label1.TabIndex = 4;
            this.label1.Text = "Játékos\r\npontszáma:";
            // 
            // pontszam1L
            // 
            this.pontszam1L.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pontszam1L.AutoSize = true;
            this.pontszam1L.BackColor = System.Drawing.Color.Transparent;
            this.pontszam1L.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.pontszam1L.Location = new System.Drawing.Point(402, 32);
            this.pontszam1L.Name = "pontszam1L";
            this.pontszam1L.Size = new System.Drawing.Size(31, 20);
            this.pontszam1L.TabIndex = 5;
            this.pontszam1L.Text = "0 p";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(304, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 40);
            this.label2.TabIndex = 6;
            this.label2.Text = "Ellenfél\r\npontszáma:";
            // 
            // pontszam2L
            // 
            this.pontszam2L.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pontszam2L.AutoSize = true;
            this.pontszam2L.BackColor = System.Drawing.Color.Transparent;
            this.pontszam2L.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.pontszam2L.ForeColor = System.Drawing.Color.White;
            this.pontszam2L.Location = new System.Drawing.Point(402, 97);
            this.pontszam2L.Name = "pontszam2L";
            this.pontszam2L.Size = new System.Drawing.Size(31, 20);
            this.pontszam2L.TabIndex = 7;
            this.pontszam2L.Text = "0 p";
            // 
            // AknaszamL
            // 
            this.AknaszamL.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.AknaszamL.AutoSize = true;
            this.AknaszamL.BackColor = System.Drawing.Color.Transparent;
            this.AknaszamL.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.AknaszamL.ForeColor = System.Drawing.Color.White;
            this.AknaszamL.Location = new System.Drawing.Point(304, 144);
            this.AknaszamL.Name = "AknaszamL";
            this.AknaszamL.Size = new System.Drawing.Size(88, 20);
            this.AknaszamL.TabIndex = 8;
            this.AknaszamL.Text = "Aknaszám:";
            // 
            // KilepesMenu
            // 
            this.KilepesMenu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.KilepesMenu.BackColor = System.Drawing.Color.OliveDrab;
            this.KilepesMenu.Location = new System.Drawing.Point(308, 199);
            this.KilepesMenu.Name = "KilepesMenu";
            this.KilepesMenu.Size = new System.Drawing.Size(105, 30);
            this.KilepesMenu.TabIndex = 10;
            this.KilepesMenu.Text = "Kilépés a menübe";
            this.KilepesMenu.UseVisualStyleBackColor = false;
            this.KilepesMenu.Click += new System.EventHandler(this.KilepesMenu_Click);
            // 
            // JatekAblak
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackgroundImage = global::Aknakereso.Properties.Resources.Aknamezo;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(442, 275);
            this.Controls.Add(this.KilepesMenu);
            this.Controls.Add(this.AknaszamL);
            this.Controls.Add(this.pontszam2L);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pontszam1L);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.kilepesB);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.Name = "JatekAblak";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Aknakereső";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.JatekAblak_FormClosing);
            this.Load += new System.EventHandler(this.JatekAblak_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button kilepesB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.Label pontszam1L;
        public System.Windows.Forms.Label pontszam2L;
        private System.Windows.Forms.Label AknaszamL;
        private System.Windows.Forms.Button KilepesMenu;


    }
}

